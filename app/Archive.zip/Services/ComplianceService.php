<?php 

namespace App\Services;

class ComplianceService
{
    protected $complianceTableService;

    public function __construct()
    {
        $this->complianceTableService = new ComplianceService();
    }
    

    public function handleUpload($path)
    {
        
    }


}
